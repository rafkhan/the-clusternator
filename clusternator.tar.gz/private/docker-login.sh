#!/bin/bash

docker login -u rafkhan -p ranglepassword -e rafael@rangle.io
